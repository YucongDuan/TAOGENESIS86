# TAOGENESIS86｜道生86

**前概念世界发生、终极问题求根与 DIKWP 回映系统**

版本：1.0.0  
模式：`MESH86_TAOGENESIS_PRECONCEPTUAL_WORLD_GENESIS`

## 核心假说

任何能够出现问题、记忆、生命、价值和行动的世界，至少需要七种开放发生条件：

`生差 Δ → 续持 ρ → 成约 κ → 转成 τ → 回果 R → 择向 ν → 重开 ω`

这七项不是七种实体，也不是已经证明的宇宙终极定律，而是一个可质疑、可运行、可重开的候选“开放发生不变量”。

## 快速运行

```bash
python dist/TAOGENESIS86.pyz summary
python dist/TAOGENESIS86.pyz operators
python dist/TAOGENESIS86.pyz questions
python dist/TAOGENESIS86.pyz explore "可能存在的天道是什么？" --out run.json
python dist/TAOGENESIS86.pyz native run.json --out run.tg86
python dist/TAOGENESIS86.pyz remember run.json --ledger living_ledger.jsonl
python dist/TAOGENESIS86.pyz reopen run.json "新证据要求重开当前整体" --out run_v2.json
python dist/TAOGENESIS86.pyz selftest
```

## 结论边界

系统不声称已经形式证明或实验验证“天道”，也不声称所有问题都能立即闭合。它的目标是：让每一个可表达问题都能被定位到发生结构中的根断裂，并明确下一步实验、行动或不可约余量。
