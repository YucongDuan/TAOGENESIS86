# 万题求根语法 / Universal Problem Root Grammar

- **R1_DIFFERENCE_COLLAPSE｜差异塌缩 / Difference collapse**：哪些不相同的内容被同一名称、指标、身份或定义压平？
- **R2_CONTINUITY_BREAK｜连续断裂 / Continuity break**：哪些来源、承诺、身份或记忆无法跨变化恢复？
- **R3_FALSE_CLOSURE｜伪闭合 / False closure**：哪个阶段性整体被误称为最终完整，哪些余量被删除？
- **R4_TRANSFORMATION_BLOCK｜转化阻塞 / Transformation blockage**：从现状到目标缺少什么现实路径、能力、资源或条件？
- **R5_CONSEQUENCE_DISCONNECT｜后果脱离 / Consequence disconnection**：为什么行动结果没有改变系统的记忆、规则和下一轮行为？
- **R6_VALUE_CAPTURE｜价值俘获 / Value capture**：谁设定目标，谁获益，谁承担代价，价值能否被质询与分叉？
- **R7_HORIZON_CLOSURE｜未来封闭 / Horizon closure**：哪个当前答案、身份或制度正在永久关闭其他可能？
- **R8_REFLEXIVE_CAPTURE｜自反俘获 / Reflexive capture**：观察者、求解器、评价器或发布行为是否正在改变问题却假装置身事外？

所有可表达问题均作为研究假说被编译到一个或多个根断裂。系统不保证当前即可闭合，但要求不可约余量和下一步行动显式。
