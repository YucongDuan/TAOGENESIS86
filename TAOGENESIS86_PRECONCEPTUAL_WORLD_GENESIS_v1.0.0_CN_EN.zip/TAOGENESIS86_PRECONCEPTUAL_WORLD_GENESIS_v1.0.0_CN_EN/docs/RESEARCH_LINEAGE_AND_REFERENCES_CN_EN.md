# 研究谱系与参考来源 / Research Lineage and References

本系统主要继承并重组：Mesh8.6、MNEMOGENESIS84、OPENBECOMING84、TIANHENG84 与 ZICHENG84。具体文件摘要见 `lineage/UPSTREAM_LINEAGE.json`。

科学与哲学参考仅提供结构启发，不构成对本系统终极主张的验证：

1. 《道德经》：道法自然、道生一等发生性表达。
2. 《周易·系辞》：一阴一阳之谓道等差异与生成表达。
3. Claude E. Shannon (1948), “A Mathematical Theory of Communication.”
4. Rolf Landauer (1961), “Irreversibility and Heat Generation in the Computing Process.”
5. Karim Nader, Glenn E. Schafe, Joseph E. LeDoux (2000), “Fear memories require protein synthesis in the amygdala for reconsolidation after retrieval.” Nature 406, 722-726.
6. Karl Friston (2010), “The free-energy principle: a unified brain theory?” Nature Reviews Neuroscience 11, 127-138.
7. Humberto Maturana and Francisco Varela, *Autopoiesis and Cognition*.
8. Ilya Prigogine, work on dissipative structures and non-equilibrium becoming.

这些来源并不被混合成一条已经证明的“万物理论”。TAOGENESIS86 的全部核心命题保持候选、可反对和可重开。
