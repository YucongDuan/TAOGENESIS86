from __future__ import annotations
import re
from typing import Any
from .dataio import roots, operators, questions
from .util import digest, slug

KEYWORDS={
 "R1_DIFFERENCE_COLLAPSE":["相同","不同","定义","分类","身份","difference","same","category","identity"],
 "R2_CONTINUITY_BREAK":["记忆","身份","来源","连续","历史","死亡","memory","continuity","source","death"],
 "R3_FALSE_CLOSURE":["本质","全部","终极","完整","理论","存在","consciousness","essence","complete","theory","existence"],
 "R4_TRANSFORMATION_BLOCK":["如何","解决","行动","实现","能力","资源","how","solve","act","implement","resource"],
 "R5_CONSEQUENCE_DISCONNECT":["后果","反馈","学习","重复","失败","consequence","feedback","learn","failure"],
 "R6_VALUE_CAPTURE":["应该","价值","善","恶","正义","目标","purpose","value","good","evil","justice","should"],
 "R7_HORIZON_CLOSURE":["未来","永远","限制","开放","自由","future","forever","limit","open","freedom"],
 "R8_REFLEXIVE_CAPTURE":["观察者","自我","自己","评价","意识","observer","self","evaluate","consciousness"],
}

def match_known(question:str):
    q=question.strip().lower()
    scored=[]
    for item in questions():
        text=(item["question_cn"]+" "+item["question_en"]).lower()
        score=0
        for token in re.findall(r"[a-z]+|[\u4e00-\u9fff]{1,4}",q):
            if token and token in text: score+=len(token)
        if q==item["id"].lower(): score+=100
        scored.append((score,item))
    scored.sort(key=lambda x:(x[0],x[1]["id"]),reverse=True)
    return scored[0][1] if scored and scored[0][0]>=2 else None

def compile_question(question:str,context:str="",purpose:str="explore root conditions") -> dict[str,Any]:
    text=(question+" "+context+" "+purpose).lower()
    root_hits=[]
    for rid,words in KEYWORDS.items():
        hit=[w for w in words if w.lower() in text]
        if hit: root_hits.append({"root_id":rid,"signals":hit})
    if not root_hits:
        root_hits=[{"root_id":"R3_FALSE_CLOSURE","signals":["generic unknown"]},{"root_id":"R4_TRANSFORMATION_BLOCK","signals":["question seeks transition"]}]
    known=match_known(question)
    handles=[{"id":"x0","role":"question-bearing trajectory"},{"id":"x1","role":"current generative field"},{"id":"x2","role":"sought or avoided future"}]
    field={
      "nodes":handles,
      "operators":[o["id"] for o in operators()],
      "constraints":["No label may settle identity or value by itself.","Every closure exposes scope and residue.","Consequences must return to memory."],
      "horizon":"OPEN",
    }
    return {
      "case_id":"TG86-"+slug(question),"question":question,"context":context,"purpose":purpose,
      "known_question_id":known["id"] if known else None,
      "deconceptualization":{
        "labels_demoted":["object","human","AI","life","truth","law","Tao"],
        "opaque_handles":handles,
        "retained_relations":["distinction","persistence","constraint","transformation","consequence","selection","reopening"]
      },
      "root_hits":root_hits,"field":field,"compile_digest":digest({"q":question,"c":context,"p":purpose,"roots":root_hits})
    }
