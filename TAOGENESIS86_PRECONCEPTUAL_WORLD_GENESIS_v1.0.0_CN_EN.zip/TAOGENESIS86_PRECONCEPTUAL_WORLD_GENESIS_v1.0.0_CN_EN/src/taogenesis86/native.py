from __future__ import annotations
import json
from .util import canonical_bytes, digest

def to_native(exploration:dict)->str:
    lines=["TG86|1"]
    q=exploration["compiled"]["question"].encode("utf-8").hex()
    lines.append("Q|"+q)
    for hit in exploration["compiled"]["root_hits"]: lines.append("R|"+hit["root_id"])
    for op in exploration["compiled"]["field"]["operators"]: lines.append("O|"+op)
    for h in exploration["hypotheses"]:
        lines.append("H|"+h["id"]+"|"+h["thesis_cn"].encode("utf-8").hex()+"|"+"".join({"PASS":"1","OPEN":"0","BLOCKED":"X"}[s] for s in h["statuses"]))
    lines.append("C|"+exploration["chosen"]["id"])
    p=exploration["dikwp_projection"]
    for k in "DIKWP": lines.append(k+"|"+json.dumps(p[k],ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8").hex())
    lines.append("X|"+exploration["exploration_digest"])
    return "\n".join(lines)+"\n"

def inspect_native(text:str)->dict:
    lines=[x for x in text.splitlines() if x.strip()]
    if not lines or lines[0]!="TG86|1": raise ValueError("invalid_header")
    counts={"roots":0,"operators":0,"hypotheses":0,"dikwp":0}
    for line in lines[1:]:
        tag=line.split("|",1)[0]
        if tag=="R": counts["roots"]+=1
        elif tag=="O": counts["operators"]+=1
        elif tag=="H": counts["hypotheses"]+=1
        elif tag in "DIKWP": counts["dikwp"]+=1
    return {"valid":counts["operators"]==7 and counts["dikwp"]==5 and counts["hypotheses"]>=3,"counts":counts,"native_digest":digest(text)}
