from __future__ import annotations
import hashlib, json, re
from pathlib import Path
from typing import Any

def canonical_bytes(obj:Any)->bytes:
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")

def digest(obj:Any)->str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()

def file_sha256(path:str|Path)->str:
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()

def slug(text:str)->str:
    s=re.sub(r"[^a-zA-Z0-9\u4e00-\u9fff]+","-",text).strip("-")
    return (s[:48] or "question").lower()

def load_json(path:str|Path)->Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))

def dump_json(path:str|Path,obj:Any)->None:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
