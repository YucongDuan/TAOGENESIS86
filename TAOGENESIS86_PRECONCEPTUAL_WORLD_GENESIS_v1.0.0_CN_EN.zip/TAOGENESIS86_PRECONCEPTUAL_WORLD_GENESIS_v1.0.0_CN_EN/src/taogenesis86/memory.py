from __future__ import annotations
import json, hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
from .util import canonical_bytes, digest
from .explorer import explore

def append_ledger(path:str|Path,event:dict[str,Any])->dict[str,Any]:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    prev="0"*64
    if p.exists():
        lines=[x for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
        if lines: prev=json.loads(lines[-1])["hash"]
    body={"timestamp":datetime.now(timezone.utc).isoformat(),"previous":prev,"event":event}
    body["hash"]=hashlib.sha256(prev.encode()+canonical_bytes(body["event"])+body["timestamp"].encode()).hexdigest()
    with p.open("a",encoding="utf-8") as f: f.write(json.dumps(body,ensure_ascii=False)+"\n")
    return body

def verify_ledger(path:str|Path)->dict[str,Any]:
    p=Path(path);prev="0"*64;count=0;errors=[]
    if not p.exists(): return {"valid":False,"count":0,"errors":["missing"]}
    for i,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
        if not line.strip(): continue
        x=json.loads(line)
        expected=hashlib.sha256(prev.encode()+canonical_bytes(x["event"])+x["timestamp"].encode()).hexdigest()
        if x.get("previous")!=prev or x.get("hash")!=expected: errors.append(i)
        prev=x.get("hash",prev);count+=1
    return {"valid":not errors,"count":count,"head":prev,"errors":errors}

def remember(exploration:dict[str,Any],ledger:str|Path)->dict[str,Any]:
    event={"type":"EXPLORATION_ACCEPTED","case_id":exploration["compiled"]["case_id"],"question":exploration["compiled"]["question"],"chosen":exploration["chosen"]["id"],"residues":exploration["residues"],"next_action":exploration["next_action"],"digest":exploration["exploration_digest"]}
    item=append_ledger(ledger,event)
    return {"record":item,"ledger":verify_ledger(ledger)}

def reopen(previous:dict[str,Any],new_evidence:str)->dict[str,Any]:
    oldq=previous["compiled"]["question"]
    ctx=previous["compiled"].get("context","") + "\nNEW EVIDENCE: "+new_evidence
    new=explore(oldq,ctx,previous["compiled"].get("purpose","explore root conditions"))
    new["revision"]={"previous_digest":previous.get("exploration_digest"),"new_evidence":new_evidence,"status":"REOPENED","preserved_residues":previous.get("residues",[])}
    new["exploration_digest"]=digest(new)
    return new
