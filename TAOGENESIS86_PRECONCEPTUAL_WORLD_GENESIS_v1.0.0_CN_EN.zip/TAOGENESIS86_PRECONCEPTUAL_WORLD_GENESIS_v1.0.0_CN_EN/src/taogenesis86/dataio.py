from __future__ import annotations
import json
from importlib.resources import files

def load(name:str):
    return json.loads(files("taogenesis86").joinpath("data",name).read_text(encoding="utf-8"))

def operators(): return load("operators.json")
def roots(): return load("problem_roots.json")
def criteria(): return load("criteria.json")
def questions(): return load("ultimate_questions.json")
def projection(): return load("dikwp_projection.json")
