from __future__ import annotations
import argparse, json
from pathlib import Path
from .dataio import operators, roots, questions, projection
from .explorer import explore
from .memory import remember, verify_ledger, reopen
from .native import to_native, inspect_native
from .conformance import conformance
from .util import load_json, dump_json

def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))

def main(argv=None):
    p=argparse.ArgumentParser(prog="taogenesis86")
    sp=p.add_subparsers(dest="cmd",required=True)
    for n in ("summary","operators","roots","questions","projection","selftest","conformance","demo"):
        sp.add_parser(n)
    q=sp.add_parser("explore");q.add_argument("question");q.add_argument("--context",default="");q.add_argument("--purpose",default="explore root conditions");q.add_argument("--out")
    q=sp.add_parser("native");q.add_argument("artifact");q.add_argument("--out",required=True)
    q=sp.add_parser("native-inspect");q.add_argument("native")
    q=sp.add_parser("remember");q.add_argument("artifact");q.add_argument("--ledger",required=True)
    q=sp.add_parser("verify-ledger");q.add_argument("ledger")
    q=sp.add_parser("reopen");q.add_argument("artifact");q.add_argument("evidence");q.add_argument("--out",required=True)
    a=p.parse_args(argv)
    if a.cmd=="summary": emit({"system":"TAOGENESIS86 / 道生86","version":"1.0.0","mode":"MESH86_TAOGENESIS_PRECONCEPTUAL_WORLD_GENESIS","candidate_tao":"OPEN_GENESIS_INVARIANT","terminal_orientation":"共自成 / co-autotelic becoming","boundary":"candidate root-exploration system; not a proved cosmic final theory"})
    elif a.cmd=="operators": emit(operators())
    elif a.cmd=="roots": emit(roots())
    elif a.cmd=="questions": emit([{"id":x["id"],"question_cn":x["question_cn"],"question_en":x["question_en"]} for x in questions()])
    elif a.cmd=="projection": emit(projection())
    elif a.cmd in ("selftest","conformance"):
        r=conformance();emit(r);return 0 if r["all_passed"] else 1
    elif a.cmd=="demo": emit(explore("可能存在的天道是什么？"))
    elif a.cmd=="explore":
        r=explore(a.question,a.context,a.purpose)
        if a.out: dump_json(a.out,r)
        emit(r)
    elif a.cmd=="native":
        text=to_native(load_json(a.artifact));Path(a.out).write_text(text,encoding="utf-8");emit({"out":a.out,"inspection":inspect_native(text)})
    elif a.cmd=="native-inspect": emit(inspect_native(Path(a.native).read_text(encoding="utf-8")))
    elif a.cmd=="remember": emit(remember(load_json(a.artifact),a.ledger))
    elif a.cmd=="verify-ledger": emit(verify_ledger(a.ledger))
    elif a.cmd=="reopen":
        r=reopen(load_json(a.artifact),a.evidence);dump_json(a.out,r);emit({"out":a.out,"digest":r["exploration_digest"],"status":r["revision"]["status"]})
    return 0
