from __future__ import annotations
import tempfile
from pathlib import Path
from .explorer import explore
from .memory import remember, verify_ledger, reopen
from .native import to_native, inspect_native
from .dataio import operators, roots, questions, criteria

def conformance():
    checks=[]
    def add(name,ok,detail=None): checks.append({"name":name,"passed":bool(ok),"detail":detail})
    add("seven_operators",len(operators())==7,len(operators()))
    add("eight_problem_roots",len(roots())==8,len(roots()))
    add("fourteen_ultimate_questions",len(questions())==14,len(questions()))
    add("eight_criteria",len(criteria())==8,len(criteria()))
    e=explore("可能存在的天道是什么？")
    add("known_question_match",e["compiled"]["known_question_id"]=="Q12",e["compiled"]["known_question_id"])
    add("open_genesis_selected",e["chosen"]["id"]=="H3_OPEN_GENESIS",e["chosen"]["id"])
    add("criterion_vector_closed",e["criterion_vector"]=="11111111",e["criterion_vector"])
    add("dikwp_projection",all(k in e["dikwp_projection"] for k in "DIKWP"))
    native=to_native(e); ni=inspect_native(native)
    add("native_valid",ni["valid"],ni)
    with tempfile.TemporaryDirectory() as td:
        ledger=Path(td)/"ledger.jsonl"
        r=remember(e,ledger)
        add("living_ledger_valid",r["ledger"]["valid"],r["ledger"])
        e2=reopen(e,"A new perspective requires the current whole to remain revisable.")
        add("reopen_preserves_previous",e2["revision"]["previous_digest"]==e["exploration_digest"])
        add("reopen_changes_digest",e2["exploration_digest"]!=e["exploration_digest"])
    e3=explore("How should a community govern autonomous AI under conflicting values?")
    add("generic_has_roots",len(e3["compiled"]["root_hits"])>=1)
    add("generic_next_action",bool(e3["next_action"]))
    return {"system":"TAOGENESIS86","version":"1.0.0","passed":sum(x["passed"] for x in checks),"total":len(checks),"all_passed":all(x["passed"] for x in checks),"checks":checks,"reference_digest":e["exploration_digest"]}
