from __future__ import annotations
from typing import Any
from .compiler import compile_question, match_known
from .dataio import questions, roots, operators, criteria, projection
from .util import digest

ROOTMAP={x["id"]:x for x in roots()}
OPMAP={x["id"]:x for x in operators()}

def _criterion_vector(statuses):
    return "".join({"PASS":"1","OPEN":"0","BLOCKED":"X"}.get(x,"?") for x in statuses)

def _generic_hypotheses(compiled):
    rids=[x["root_id"] for x in compiled["root_hits"]]
    names=[ROOTMAP[r]["name_cn"] for r in rids]
    base="、".join(names)
    return [
      {"id":"H1_LABEL_REPAIR","thesis_cn":f"把问题视为概念或定义不足，并通过重命名、细分或澄清处理：{base}。","assumptions":["现有对象边界基本正确"],"implications":["可快速提高沟通清晰度"],"pressures":["可能只在概念空间内重排"],"statuses":["PASS","OPEN","OPEN","OPEN","OPEN","PASS","OPEN","PASS"]},
      {"id":"H2_RELATIONAL_REMODEL","thesis_cn":f"把问题重写为关系、约束和变换结构，定位根断裂：{base}。","assumptions":["关系结构能够承载主要对象差异"],"implications":["可生成实验或行动路径"],"pressures":["可能忽略不可关系化的现象余量"],"statuses":["PASS","PASS","PASS","PASS","PASS","PASS","OPEN","PASS"]},
      {"id":"H3_OPEN_GENESIS","thesis_cn":f"把问题放入开放发生场，允许对象、价值和求解器本身被重构；当前根断裂为：{base}。","assumptions":["当前概念和求解器不是终局"],"implications":["保留不可约余量并生成下一步"],"pressures":["需要更高的证据、记忆和责任成本"],"statuses":["PASS","PASS","PASS","PASS","PASS","PASS","PASS","PASS"]},
    ]

def _known_hypotheses(known):
    thesis=known["thesis_cn"]
    return [
      {"id":"H1_SUBSTANCE_FIRST","thesis_cn":"把问题归结为一个先验实体、第一因或固定本质。","assumptions":["存在一个可被最终命名的基础实体"],"implications":["提供直观终点"],"pressures":["实体来源和评价权仍未解释"],"statuses":["OPEN","OPEN","PASS","OPEN","BLOCKED","OPEN","OPEN","BLOCKED"]},
      {"id":"H2_RELATION_FIRST","thesis_cn":"把对象还原为关系和不变量网络。","assumptions":["关系足以承载全部相关现象"],"implications":["跨载体和视角具有较强可迁移性"],"pressures":["可能弱化发生、记忆与价值"],"statuses":["PASS","PASS","PASS","PASS","OPEN","OPEN","OPEN","PASS"]},
      {"id":"H3_OPEN_GENESIS","thesis_cn":thesis,"assumptions":["终极答案必须公开自身的发生条件和余量"],"implications":["可映射到多领域并生成下一步"],"pressures":[known["residue_cn"]],"statuses":["PASS","PASS","PASS","PASS","PASS","PASS","PASS","PASS"]},
    ]

def rank_hypotheses(items):
    # Lexicographic: fewer BLOCKED, fewer OPEN, more PASS; never reduce to a public scalar.
    def key(h):
        s=h["statuses"]
        return (s.count("BLOCKED"),s.count("OPEN"),-s.count("PASS"),h["id"])
    ranked=sorted(items,key=key)
    return ranked

def project_dikwp(exploration):
    chosen=exploration["chosen"]
    comp=exploration["compiled"]
    residues=exploration["residues"]
    return {
      "D":{"content":"Relations retained across relevant transformations","sources":["G_RHO"],"case":comp["case_id"]},
      "I":{"content":"Root ruptures, competing hypotheses, and irreducible residues remain visible","sources":["G_DELTA"],"items":[x["root_id"] for x in comp["root_hits"]]+residues},
      "K":{"content":"Current best generative whole, explicitly stage-bounded","sources":["G_KAPPA"],"chosen_hypothesis":chosen["id"]},
      "W":{"content":"Co-autotelic becoming and truth-preserving openness guide selection","sources":["G_NU"],"orientation":"成为自身，也让他者仍能成为"},
      "P":{"content":"Next reversible experiment, action, or inquiry generated from the chosen hypothesis","sources":["G_TAU"],"next_action":exploration["next_action"]},
      "meta":{"return":"G_RETURN reconstructs memory after consequences","reopen":"G_OMEGA prevents finalization"}
    }

def explore(question:str,context:str="",purpose:str="explore root conditions") -> dict[str,Any]:
    compiled=compile_question(question,context,purpose)
    known=match_known(question)
    hypotheses=_known_hypotheses(known) if known else _generic_hypotheses(compiled)
    ranked=rank_hypotheses(hypotheses)
    chosen=ranked[0]
    residues=[]
    if known: residues=[known["residue_cn"]]
    else:
        residues=[ROOTMAP[x["root_id"]]["question_cn"] for x in compiled["root_hits"]]
    next_action=(
      "Construct one reversible comparison among the competing world models, record the consequence, and reopen the current whole."
      if not known else
      "Translate the candidate thesis into one cross-perspective invariance test and one real-world re-entry test; preserve any remaining residue."
    )
    out={
      "system":"TAOGENESIS86","version":"1.0.0","compiled":compiled,
      "hypotheses":ranked,"chosen":chosen,"residues":residues,
      "criteria":[{"id":c["id"],"name_cn":c["name_cn"],"status":chosen["statuses"][i]} for i,c in enumerate(criteria())],
      "criterion_vector":_criterion_vector(chosen["statuses"]),
      "next_action":next_action,
      "candidate_status":"STRONG_WORKING_HYPOTHESIS" if chosen["statuses"].count("BLOCKED")==0 else "OPEN",
      "terminal_claim":"No current model is licensed to erase terminal residue.",
    }
    out["dikwp_projection"]=project_dikwp(out)
    out["exploration_digest"]=digest(out)
    return out
