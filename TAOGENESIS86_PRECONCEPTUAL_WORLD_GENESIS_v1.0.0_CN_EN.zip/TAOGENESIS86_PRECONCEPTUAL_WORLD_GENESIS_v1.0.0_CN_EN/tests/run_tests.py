import sys,tempfile,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"src"))
from taogenesis86.conformance import conformance
from taogenesis86.explorer import explore
from taogenesis86.native import to_native,inspect_native
from taogenesis86.memory import remember,verify_ledger,reopen

t=[]
def check(n,v): t.append((n,bool(v)))
r=conformance();check("conformance",r["all_passed"])
e=explore("什么是生命？");check("known_q",e["compiled"]["known_question_id"]=="Q06")
check("chosen",e["chosen"]["id"]=="H3_OPEN_GENESIS")
check("native",inspect_native(to_native(e))["valid"])
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/"l.jsonl";remember(e,p);check("ledger",verify_ledger(p)["valid"])
    e2=reopen(e,"new evidence");check("reopen",e2["revision"]["status"]=="REOPENED")
for n,v in t: print(("PASS" if v else "FAIL"),n)
print(sum(v for _,v in t),"passed,",sum(not v for _,v in t),"failed")
raise SystemExit(0 if all(v for _,v in t) else 1)
